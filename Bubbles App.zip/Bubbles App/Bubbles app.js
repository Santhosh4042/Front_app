const circle1 = document.getElementById('circle1');
const arrow1 = document.getElementById('arrow1')


circle1.addEventListener('click', ()=> {
    circle1.style.backgroundColor = 'darkgrey';
    arrow1.style.marginLeft = '120px';

});
const circle2 = document.getElementById('circle2');
const arrow2 = document.getElementById('arrow2')

circle2.addEventListener('click', ()=> {
    circle2.style.backgroundColor = 'orange';
    arrow2.style.marginLeft = '120px';
});

const circle3 = document.getElementById('circle3');
const arrow3 = document.getElementById('arrow3')

circle3.addEventListener('click', ()=> {
    circle3.style.backgroundColor = 'purple';
    arrow3.style.marginLeft = '120px';

});
const circle4 = document.getElementById('circle4');
const arrow4 = document.getElementById('arrow4')

circle4.addEventListener('click', ()=> {
    circle4.style.backgroundColor = 'pink';
    arrow4.style.marginLeft = '120px';
});

const bot = document.getElementById('bot');
bot.addEventListener('click', function(){
    location.reload();
});
